// JavaScript source code

function checkForm() {
    return checkUserName() && checkPwd() && recheckPwd() && checkidcard() && checktel() && checkage() && checkGender();
    form_reg.submit();
}

function checkUserName() {
    //用户名不能为空
    var userName = document.getElementById("userName").value;
    var name = document.getElementById("name");
   
    if (userName == "") {
        //name.color = "red";
        name.innerHTML = "<font color='red'>用户名不能为空</font>";
        return false
    }
 
    name.innerHTML = "<font color='green'>√</font>";
    //name.color = "green";
    return true;
}

function checkPwd() {
    //验证密码
    var password = document.getElementById("password").value;
    //alert(password);
    var pwd = document.getElementById("pwd");
    //var reg = /[0-9a-zA-Z]{6,8}/;
    if (password == "") {
        //pwd.color = "red";
        pwd.innerHTML = "<font color='red'>密码不能为空</font>";
        return false;
    }
    
    pwd.innerHTML = "<font color='green'>√</font>";
    // pwd.color = "green";
    return true;
}
function recheckPwd() {
    var password = document.getElementById("password").value;
    var repassword = document.getElementById("repassword").value;
    var repwd = document.getElementById("repwd");
    if (repassword == "") {
        // repwd.color = "red";
        repwd.innerHTML = "<font color='red'>密码不能为空</font>";
        return false;
    }
    if (repassword != password) {
        // repwd.color = "red";
        document.getElementById("repwd").innerHTML = "<font color='red'>密码需一致</font>";
        return false;
    }
    repwd.innerHTML = "<font color='green'>√";
    //repwd.color = "green";
    return true;
}
function checkage() {
    var age = document.getElementById("age").value;
    var aged = document.getElementById("aged");
    var reg = /\d/;
    if (!reg.test(age)) {
        aged.innerHTML = "<font color='red'>请填写有效的年龄信息</font>";
        return false;
    }
    aged.innerHTML = "<font color='green'>√</font>";
    return true;
}
function checkidcard() {
    var idcard = document.getElementById("idcard").value;
    var idnum = document.getElementById("idnum");
    var reg = /^[0-9a-zA-Z]{18}$/;
    
    if (idcard == "") {
        idnum.innerHTML = "<font color='red'>身份证号不能为空</font>";
        return false;
    }
    if (!reg.test(idcard)) {
        idnum.innerHTML = "<font color='red'>身份证号要求是18位数</font>"
        return false;
    }
    idnum.innerHTML = "<font color='green'>√</font>";
    return true;
}
function checktel() {
    var tel = document.getElementById("tel").value;
    var checktell = document.getElementById("checktell");
    var reg = /^[0-9]{11}$/;
    if (tel == "") {
        checktell.innerHTML = "<font color='red'>联系电话不能为空</font>";
        return false;
    }
    if (!reg.test(tel)) {
        checktell.innerHTML = "<font color='red'>电话号码由11位数字组成</font>";
        return false;
    }
    checktell.innerHTML = "<font color='green'>√</font>";
    return true;
}

function checkGender() {
    
    var gender = "";
    var genderd = document.getElementById("genderd");
    //获取所有名称为sex的标签
    var sex = document.getElementsByName("sex");
    //遍历这些名称为sex的标签
    for (var i = 0; i < sex.length; ++i) {
        //如果某个sex被选中，则记录
        if (sex[i].checked)
            gender = sex[i].value;
    }
    if (gender == "") {
        genderd.innerHTML = "<font color='red'>请选择性别！</font>";
        return  false;
    } 
    return true;
}

function clearText(fontId) {
    //document.getElementById(inpId).value = "";
    document.getElementById(fontId).innerHTML = "";

}


