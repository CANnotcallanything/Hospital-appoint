package beans;

import java.util.Date;




public class Appoint_Result_bean {
	private int ar_num;
	private String ar_idcard;
	private String ar_name;
	private int ar_idnum;
	private String ar_sex;
	//private Date ar_time;
	private String ar_time;
	private String ar_departname;
	private String ar_docname;
	private String ar_describe;
	
	public int getAr_num() {
		return ar_num;
	}
	public void setAr_num(int arNum) {
		ar_num = arNum;
	}
	public String getAr_idcard() {
		return ar_idcard;
	}
	public void setAr_idcard(String arIdcard) {
		ar_idcard = arIdcard;
	}
	public String getAr_name() {
		return ar_name;
	}
	public void setAr_name(String arName) {
		ar_name = arName;
	}
	public int getAr_idnum() {
		return ar_idnum;
	}
	public void setAr_idnum(int arIdnum) {
		ar_idnum = arIdnum;
	}
	public String getAr_sex() {
		return ar_sex;
	}
	public void setAr_sex(String arSex) {
		ar_sex = arSex;
	}
	public String getAr_time() {
		return ar_time;
	}
	public void setAr_time(String arTime) {
		ar_time = arTime;
	}
	public String getAr_departname() {
		return ar_departname;
	}
	public void setAr_departname(String arDepartname) {
		ar_departname = arDepartname;
	}
	public String getAr_docname() {
		return ar_docname;
	}
	public void setAr_docname(String arDocname) {
		ar_docname = arDocname;
	}
	public String getAr_describe() {
		return ar_describe;
	}
	public void setAr_describe(String arDescribe) {
		ar_describe = arDescribe;
	}

	
}
