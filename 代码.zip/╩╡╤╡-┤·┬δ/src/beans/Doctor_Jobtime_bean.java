package beans;

import java.util.Date;

public class Doctor_Jobtime_bean {
	private int jobn;
	private String jobdepartid;
	private String jobdocid;
	//private Date jobday;
	private String jobday;
	private int jobnumber;
	public int getJobn() {
		return jobn;
	}
	public void setJobn(int jobn) {
		this.jobn = jobn;
	}
	public String getJobdepartid() {
		return jobdepartid;
	}
	public void setJobdepartid(String jobdepartid) {
		this.jobdepartid = jobdepartid;
	}
	public String getJobdocid() {
		return jobdocid;
	}
	public void setJobdocid(String jobdocid) {
		this.jobdocid = jobdocid;
	}
	
	public String getJobday() {
		return jobday;
	}
	public void setJobday(String jobday) {
		this.jobday = jobday;
	}
	public int getJobnumber() {
		return jobnumber;
	}
	public void setJobnumber(int jobnumber) {
		this.jobnumber = jobnumber;
	}
	
}
