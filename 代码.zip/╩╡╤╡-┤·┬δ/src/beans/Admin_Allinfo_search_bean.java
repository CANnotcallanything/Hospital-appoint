package beans;

public class Admin_Allinfo_search_bean {
	private String adnum;
	private String adidcard;
	private String adname;
	private String adsex;
	private String adage; 
	private String adphone;
	private String adpwd;
	public String getAdnum() {
		return adnum;
	}
	public void setAdnum(String adnum) {
		this.adnum = adnum;
	}
	public String getAdidcard() {
		return adidcard;
	}
	public void setAdidcard(String adidcard) {
		this.adidcard = adidcard;
	}
	public String getAdname() {
		return adname;
	}
	public void setAdname(String adname) {
		this.adname = adname;
	}
	public String getAdsex() {
		return adsex;
	}
	public void setAdsex(String adsex) {
		this.adsex = adsex;
	}
	public String getAdage() {
		return adage;
	}
	public void setAdage(String adage) {
		this.adage = adage;
	}
	public String getAdphone() {
		return adphone;
	}
	public void setAdphone(String adphone) {
		this.adphone = adphone;
	}
	public String getAdpwd() {
		return adpwd;
	}
	public void setAdpwd(String adpwd) {
		this.adpwd = adpwd;
	}
	
	
}
