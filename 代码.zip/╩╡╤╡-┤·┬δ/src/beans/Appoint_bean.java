package beans;

import java.util.Date;

public class Appoint_bean {
	private String departid;
	private String departname;
	private String docid;
	private String docname;
	private String docintro;
	private int jobn;
	//private Date jobday;
	private String jobday;
	private int jobnumber;
	
	
	public int getJobn() {
		return jobn;
	}
	public void setJobn(int jobn) {
		this.jobn = jobn;
	}
	
	public String getDocid() {
		return docid;
	}
	public void setDocid(String docid) {
		this.docid = docid;
	}
	
	public String getDepartid() {
		return departid;
	}
	public void setDepartid(String departid) {
		this.departid = departid;
	}
	public String getDepartname() {
		return departname;
	}
	public void setDepartname(String departname) {
		this.departname = departname;
	}
	public String getDocname() {
		return docname;
	}
	public void setDocname(String docname) {
		this.docname = docname;
	}
	public String getDocintro() {
		return docintro;
	}
	public void setDocintro(String docintro) {
		this.docintro = docintro;
	}

	public String getJobday() {
		return jobday;
	}
	public void setJobday(String jobday) {
		this.jobday = jobday;
	}
	public int getJobnumber() {
		return jobnumber;
	}
	public void setJobnumber(int jobnumber) {
		this.jobnumber = jobnumber;
	}
	
	
	
}
