package beans;

public class Depart_Doc_info_bean {
	private String docid;
	private String docname;
	private String docintro; 
	private String departid;
	private String departname;
	private String departintro;

	public String getDocid() {
		return docid;
	}
	public void setDocid(String docid) {
		this.docid = docid;
	}
	public String getDocname() {
		return docname;
	}
	public void setDocname(String docname) {
		this.docname = docname;
	}
	public String getDocintro() {
		return docintro;
	}
	public void setDocintro(String docintro) {
		this.docintro = docintro;
	}
	public String getDepartid() {
		return departid;
	}
	public void setDepartid(String departid) {
		this.departid = departid;
	}
	public String getDepartname() {
		return departname;
	}
	public void setDepartname(String departname) {
		this.departname = departname;
	}
	public String getDepartintro() {
		return departintro;
	}
	public void setDepartintro(String departintro) {
		this.departintro = departintro;
	}
	
}
