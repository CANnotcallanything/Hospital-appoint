package beans;

public class Depart_info_bean {
	private String departid;
	private String departname;
	private String departintro;
	
	public String getDepartid() {
		return departid;
	}

	public void setDepartid(String departid) {
		this.departid = departid;
	}

	public String getDepartname() {
		return departname;
	}

	public void setDepartname(String departname) {
		this.departname = departname;
	}

	public String getDepartintro() {
		return departintro;
	}

	public void setDepartintro(String departintro) {
		this.departintro = departintro;
	}
	
}
