package beans;

public class P_getinfo_bean {
	private String username;
	private String pwd;
	private String sex;
	private String age;
	private String idcard;
	private String tel;
	private String medintro;
	private int idnum;
	public void setIdnum(int idnum) {
		this.idnum = idnum;
	}
	public int getIdnum() {
		return idnum;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getSex() {
		return sex;
	}
	public void setSex(String sex) {
		this.sex = sex;
	}
	public String getAge() {
		return age;
	}
	public void setAge(String age) {
		this.age = age;
	}
	public String getIdcard() {
		return idcard;
	}
	public void setIdcard(String idcard) {
		this.idcard = idcard;
	}
	public String getTel() {
		return tel;
	}
	public void setTel(String tel) {
		this.tel = tel;
	}
	public String getMedintro() {
		return medintro;
	}
	public void setMedintro(String medintro) {
		this.medintro = medintro;
	}
	
	
}
