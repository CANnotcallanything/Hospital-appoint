package beans;

public class Admin_bean {
	private String admin_num;
	private String admin_id;
	private String admin_name;
	public String getAdmin_name() {
		return admin_name;
	}
	public void setAdmin_name(String adminName) {
		admin_name = adminName;
	}
	public String getAdmin_num() {
		return admin_num;
	}
	public void setAdmin_num(String adminNum) {
		admin_num = adminNum;
	}
	public String getAdmin_id() {
		return admin_id;
	}
	public void setAdmin_id(String adminId) {
		admin_id = adminId;
	}
	
	
}
