package beans;


public class Comment_bean {
	private int comid;
	private int compidnum;
	private String comdocid;
	private String comment;
	private String comtime;
	public int getComid() {
		return comid;
	}
	public void setComid(int comid) {
		this.comid = comid;
	}
	public int getCompidnum() {
		return compidnum;
	}
	public void setCompidnum(int compidnum) {
		this.compidnum = compidnum;
	}
	public String getComdocid() {
		return comdocid;
	}
	public void setComdocid(String comdocid) {
		this.comdocid = comdocid;
	}
	public String getComment() {
		return comment;
	}
	public void setComment(String comment) {
		this.comment = comment;
	}
	public String getComtime() {
		return comtime;
	}
	public void setComtime(String comtime) {
		this.comtime = comtime;
	}
	
}
