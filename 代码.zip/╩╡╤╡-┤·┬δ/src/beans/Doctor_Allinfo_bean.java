package beans;

public class Doctor_Allinfo_bean {
	private String docid;
	private String docname;
	private String docsex;
	private String docage;
	private String docidcard;
	private String docdepartid;
	private String docphone;
	private String docemail;
	private String docintro;
	private String docpwd;
	public String getDocpwd() {
		return docpwd;
	}
	public void setDocpwd(String docpwd) {
		this.docpwd = docpwd;
	}
	public String getDocid() {
		return docid;
	}
	public void setDocid(String docid) {
		this.docid = docid;
	}
	public String getDocname() {
		return docname;
	}
	public void setDocname(String docname) {
		this.docname = docname;
	}
	public String getDocsex() {
		return docsex;
	}
	public void setDocsex(String docsex) {
		this.docsex = docsex;
	}
	public String getDocage() {
		return docage;
	}
	public void setDocage(String docage) {
		this.docage = docage;
	}
	public String getDocidcard() {
		return docidcard;
	}
	public void setDocidcard(String docidcard) {
		this.docidcard = docidcard;
	}
	public String getDocdepartid() {
		return docdepartid;
	}
	public void setDocdepartid(String docdepartid) {
		this.docdepartid = docdepartid;
	}
	public String getDocphone() {
		return docphone;
	}
	public void setDocphone(String docphone) {
		this.docphone = docphone;
	}
	public String getDocemail() {
		return docemail;
	}
	public void setDocemail(String docemail) {
		this.docemail = docemail;
	}
	public String getDocintro() {
		return docintro;
	}
	public void setDocintro(String docintro) {
		this.docintro = docintro;
	}
		
}
