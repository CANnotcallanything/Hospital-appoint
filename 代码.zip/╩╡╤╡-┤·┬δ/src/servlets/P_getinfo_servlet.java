package servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daos.Functions_dao;

import beans.P_getinfo_bean;

public class P_getinfo_servlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public P_getinfo_servlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
			doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		request.setCharacterEncoding("UTF-8");
		
    	String username=request.getParameter("userName");
    	String pwd=request.getParameter("password");
    	String sex=request.getParameter("sex");
    	String age=request.getParameter("age");
    	String idcard=request.getParameter("idcard");
    	String tel=request.getParameter("tel");
    	String medintro=request.getParameter("medintro");
    		
    	P_getinfo_bean info_bean=new P_getinfo_bean();
    	info_bean.setUsername(username);
    	info_bean.setPwd(pwd);
    	info_bean.setSex(sex);
    	info_bean.setAge(age);
    	info_bean.setIdcard(idcard);
    	info_bean.setTel(tel);
    	info_bean.setMedintro(medintro);
    	
    	//ArrayList P_info=new ArrayList();
    	//P_info.add(info_bean);
    	
    	//session.setAttribute("patient",P_info);
    	
    	Functions_dao info_dao=new Functions_dao();
    	//int b=info_dao.get_patientinfo(P_info);
    	
    	try {
			info_dao.get_patientinfo(info_bean);
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
 
    	response.sendRedirect("/Hospital/Pages/P_login.jsp?login=success");
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
