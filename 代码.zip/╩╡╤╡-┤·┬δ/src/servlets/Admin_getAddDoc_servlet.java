package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import daos.Functions_dao;

import beans.Doctor_Allinfo_bean;

public class Admin_getAddDoc_servlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public Admin_getAddDoc_servlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		request.setCharacterEncoding("UTF-8");
    	String docid=request.getParameter("docid");
    	String docname=request.getParameter("docname");
    	String docsex=request.getParameter("docsex");
    	String docage=request.getParameter("docage");
    	String docidcard=request.getParameter("docidcard");
    	String docdepartid=request.getParameter("docdepartid");	
    	String docphone=request.getParameter("docphone");
    	String docemail=request.getParameter("docemail");
    	String docintro=request.getParameter("docintro");
    	String docpwd=request.getParameter("docpwd");
 			
 		Functions_dao doctor=new Functions_dao();
    	
    	//查询数据库中是否有该工号的医生
    	ArrayList checkdoc;
		try {
			checkdoc = (ArrayList)doctor.queryDoctors(docid);
			
			//在数据库查询该科室编号是否存在,存在才允许添加
			ArrayList checkdocdeid=(ArrayList)doctor.queryDepartment(docdepartid);
	    	
	    	if(!checkdoc.isEmpty()){
	    		response.sendRedirect("/Hospital/Pages/Admin_manage/manage_doctor/Admin_doctor.jsp?error3=n");
	    		}
	    	else if(!checkdocdeid.isEmpty()){
	    		Doctor_Allinfo_bean adddoc=new Doctor_Allinfo_bean();
	    		
	    		adddoc.setDocid(docid);
	    		adddoc.setDocname(docname);
	    		adddoc.setDocsex(docsex);
	    		adddoc.setDocage(docage);
	    		adddoc.setDocidcard(docidcard);
	    		adddoc.setDocdepartid(docdepartid);
	    		adddoc.setDocphone(docphone);
	    		adddoc.setDocemail(docemail);
	    		adddoc.setDocintro(docintro);
	    		adddoc.setDocpwd(docpwd);
	    		
	    		doctor.addDoctor(adddoc);

				response.sendRedirect("/Hospital/Pages/Admin_manage/manage_doctor/Admin_doctor.jsp?success=y");
	    	}
	    	
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    	
    	
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
