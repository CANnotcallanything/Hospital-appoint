package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import daos.Appoint_dao;

import beans.Appoint_Result_bean;
import beans.Appoint_bean;
import beans.P_check_bean;

public class Appoint_getConfirm_servlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public Appoint_getConfirm_servlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		request.setCharacterEncoding("UTF-8");
   		//String docid=request.getParameter("docid");
		String jobn=request.getParameter("jobn");
		
   		HttpSession session=request.getSession();
   		
   		 ArrayList parray=(ArrayList)session.getAttribute("parray");
               for(int i=0;i<parray.size();i++){
                	P_check_bean pbean=(P_check_bean)parray.get(i);
   		
   		Appoint_dao appoint=new Appoint_dao();
   		
   		ArrayList confirmAppoint;
		try {
			confirmAppoint = (ArrayList)appoint.Appoint_confirm_n(Integer.parseInt(jobn));
			
			for(int a=0;a<confirmAppoint.size();a++){
	   			Appoint_bean ap=(Appoint_bean)confirmAppoint.get(a);
	   			
	   			Appoint_Result_bean	appresult=new Appoint_Result_bean();
	   			appresult.setAr_name(pbean.getName());
	     		appresult.setAr_idcard(pbean.getIdcard());
	     		appresult.setAr_idnum(pbean.getIdnum());
	     		appresult.setAr_sex(pbean.getSex());
	     		appresult.setAr_time(ap.getJobday());
	     		appresult.setAr_departname(ap.getDepartname());
	     		appresult.setAr_docname(ap.getDocname());
	     		appresult.setAr_describe(pbean.getMedintro());
	     		
	     		appoint.insertConfirm_appoint(appresult);
	   		}
			
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
   		
   		
     }
	
	response.sendRedirect("/Hospital/Pages/P_show.jsp");
	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
