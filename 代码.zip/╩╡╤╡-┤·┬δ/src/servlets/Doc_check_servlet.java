package servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import daos.Functions_dao;

public class Doc_check_servlet extends HttpServlet {

	/**
	 * Constructor of the object.
	 */
	public Doc_check_servlet() {
		super();
	}

	/**
	 * Destruction of the servlet. <br>
	 */
	public void destroy() {
		super.destroy(); // Just puts "destroy" string in log
		// Put your code here
	}

	/**
	 * The doGet method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to get.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

			doPost(request,response);
	}

	/**
	 * The doPost method of the servlet. <br>
	 *
	 * This method is called when a form has its tag value method equals to post.
	 * 
	 * @param request the request send by the client to the server
	 * @param response the response send by the server to the client
	 * @throws ServletException if an error occurred
	 * @throws IOException if an error occurred
	 */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html;charset=UTF-8");
		PrintWriter out = response.getWriter();
		
		request.setCharacterEncoding("UTF-8");
    	
		HttpSession session=request.getSession();
		
    	String name=request.getParameter("name"); 
    	String pwd=request.getParameter("password"); 
		String check = request.getParameter("check");
		
		if (name!= null && pwd != null) {	
			if (check!= null) {
				Cookie namecookie = new Cookie("name1", name);
				namecookie.setMaxAge(60);
				response.addCookie(namecookie);
				
				Cookie pwdcookie = new Cookie("pwd1", pwd);
				pwdcookie.setMaxAge(60);
				response.addCookie(pwdcookie);
				
				Functions_dao doc=new Functions_dao();
		    	
		    	ArrayList doctor;
				try {
					doctor = (ArrayList)doc.checkdoctor(name, pwd);
					if(doctor.isEmpty())
				    	response.sendRedirect("/Hospital/Pages/D_login.jsp?error1=y");
				    else{
				    		session.setAttribute("doctor",doctor);
				    		response.sendRedirect("/Hospital/Pages/D_show.jsp?success=y");
				    	}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			else{
				Functions_dao doc=new Functions_dao();
		    	
		    	ArrayList doctor;
				try {
					doctor = (ArrayList)doc.checkdoctor(name, pwd);
					if(doctor.isEmpty())
				    	response.sendRedirect("/Hospital/Pages/D_login.jsp?error1=y");
				    else{
				    		session.setAttribute("doctor",doctor);
				    		response.sendRedirect("/Hospital/Pages/D_show.jsp?success=y");
				    	}
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}	
			}
		} 
		else {
			response.sendRedirect("/Hospital/Pages/D_login.jsp?error2=y");
		}
		
		

	}

	/**
	 * Initialization of the servlet. <br>
	 *
	 * @throws ServletException if an error occurs
	 */
	public void init() throws ServletException {
		// Put your code here
	}

}
