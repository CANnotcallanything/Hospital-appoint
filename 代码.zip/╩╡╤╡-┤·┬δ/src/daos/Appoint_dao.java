package daos;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import java.util.Date;

import beans.Appoint_Result_bean;
import beans.Appoint_bean;
import beans.Doctor_Allinfo_bean;
import beans.Doctor_Jobtime_bean;
import beans.P_getinfo_bean;


public class Appoint_dao {
	
	Connection con=Connect_dao.connect();
	
	//在数据库中查询可预约的信息（按科室编号，用于显示全部可预约信息的）
	public ArrayList Appoint_info(String departid)throws Exception{
		
		ArrayList appoint=new ArrayList();
		
	    //Statement st=con.createStatement();
	    
	    String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_id,D_name,D_intro,H_JobTime.Job_n,Job_day,Job_number FROM H_Department,H_Doctor,H_JobTime WHERE H_Department.D_departid=H_Doctor.D_departid and H_Department.D_departid=H_JobTime.Job_Departid and H_Doctor.D_id=H_JobTime.Job_Docid and H_Department.D_departid=?";
	    
	    PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1,departid);
	    
	    
	    //ResultSet rs=st.executeQuery(sql);
	    
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Appoint_bean appbean=new Appoint_bean();
	    	appbean.setJobn(rs.getInt("Job_n"));
	    	appbean.setDepartid(rs.getString("D_departid"));
	    	appbean.setDepartname(rs.getString("D_departname"));
	    	appbean.setDocid(rs.getString("D_id"));
	    	appbean.setDocname(rs.getString("D_name"));
	    	appbean.setDocintro(rs.getString("D_intro"));
	    	appbean.setJobday(rs.getString("Job_day"));
	    	appbean.setJobnumber(rs.getInt("Job_number"));
	    	
	    	appoint.add(appbean);
	    	
	    	//HttpServletRequest request=null;
	    	//HttpSession session=request.getSession();
	    	//session.setAttribute("availappoint", appoint);
	    }
	    return appoint;
	   }
	
	
	//在数据库中查询可预约的信息（排班表的序号，用于用户确定的）
	public ArrayList Appoint_confirm_n(int jobn)throws Exception{
		
		ArrayList confirm_n=new ArrayList();
		
	    //Statement st=con.createStatement();
	    
	    String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_id,D_name,D_intro,H_JobTime.Job_n,Job_day,Job_number FROM H_Department,H_Doctor,H_JobTime WHERE H_Department.D_departid=H_Doctor.D_departid and H_Department.D_departid=H_JobTime.Job_Departid and H_Doctor.D_id=H_JobTime.Job_Docid and H_JobTime.Job_n=?";
	    
	    PreparedStatement ps=con.prepareStatement(sql);
	    ps.setInt(1,jobn);
	    
	    
	    //ResultSet rs=st.executeQuery(sql);
	    
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Appoint_bean app_n=new Appoint_bean();  
	    	app_n.setJobn(rs.getInt("Job_n"));
	    	app_n.setDepartid(rs.getString("D_departid"));
	    	app_n.setDepartname(rs.getString("D_departname"));
	    	app_n.setDocid(rs.getString("D_id"));
	    	app_n.setDocname(rs.getString("D_name"));
	    	app_n.setDocintro(rs.getString("D_intro"));
	    	app_n.setJobday(rs.getString("Job_day"));
	    	app_n.setJobnumber(rs.getInt("Job_number"));
	    	
	    	confirm_n.add(app_n);
	    	
	    	//HttpServletRequest request=null;
	    	//HttpSession session=request.getSession();
	    	//session.setAttribute("availappoint", appoint);
	    }
	    return confirm_n;
	   }
	

	//在数据库中直接查询可预约的信息
	public ArrayList Query_Appoint_info()throws Exception{
		
		ArrayList appoint2=new ArrayList();
		
	    //Statement st=con.createStatement();
	    
	    String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_id,D_name,D_intro,H_JobTime.Job_n,Job_day,Job_number FROM H_Department,H_Doctor,H_JobTime WHERE H_Department.D_departid=H_Doctor.D_departid and H_Department.D_departid=H_JobTime.Job_Departid and H_Doctor.D_id=H_JobTime.Job_Docid";
	    
	    PreparedStatement ps=con.prepareStatement(sql);
	    
	    
	    //ResultSet rs=st.executeQuery(sql);
	    
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Appoint_bean appbean2=new Appoint_bean();  
	    	appbean2.setJobn(rs.getInt("Job_n"));
	    	appbean2.setDepartid(rs.getString("D_departid"));
	    	appbean2.setDepartname(rs.getString("D_departname"));
	    	appbean2.setDocid(rs.getString("D_id"));
	    	appbean2.setDocname(rs.getString("D_name"));
	    	appbean2.setDocintro(rs.getString("D_intro"));
	    	appbean2.setJobday(rs.getString("Job_day"));
	    	appbean2.setJobnumber(rs.getInt("Job_number"));
	    	
	    	appoint2.add(appbean2);
	    	
	    	//HttpServletRequest request=null;
	    	//HttpSession session=request.getSession();
	    	//session.setAttribute("availappoint", appoint);
	    }
	    return appoint2;
	   }
	
	//在数据库中插入用户选定的预约信息
	public void insertConfirm_appoint(Appoint_Result_bean apresult)throws Exception{
		
		String sql="INSERT INTO H_AppointResult VALUES(?,?,?,?,?,?,?,?)";
		
		PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1,apresult.getAr_idcard());
	    ps.setString(2,apresult.getAr_name());
	    ps.setInt(3,apresult.getAr_idnum());
	    ps.setString(4,apresult.getAr_sex());
	    ps.setString(5, apresult.getAr_time());
	   // ps.setDate(5, new java.sql.Date(apresult.getAr_time().getTime()));
	    ps.setString(6,apresult.getAr_departname());
	    ps.setString(7,apresult.getAr_docname());	
	    ps.setString(8,apresult.getAr_describe());
	  
	    ps.executeUpdate();
		
	   }
	

	//在数据库中查询用户的（历史）预约信息
	public ArrayList SearchPatient_appoint(int idnum)throws Exception{
		
		ArrayList queryapp=new ArrayList();
		
		String sql="SELECT * FROM H_AppointResult WHERE AR_idnum=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,idnum);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Appoint_Result_bean AR=new Appoint_Result_bean();
			AR.setAr_num(rs.getInt("AR_num"));
			AR.setAr_name(rs.getString("AR_name"));
			AR.setAr_idcard(rs.getString("AR_idcard"));
			AR.setAr_idnum(rs.getInt("AR_idnum"));
			AR.setAr_sex(rs.getString("AR_sex"));
			AR.setAr_time(rs.getString("AR_time"));
			AR.setAr_departname(rs.getString("AR_departname"));
			AR.setAr_docname(rs.getString("AR_docname"));
			AR.setAr_describe(rs.getString("AR_describe"));
			
			queryapp.add(AR);
		}
	  
	    return queryapp;
		
	   }
	

	//在数据库中查询医生的（历史）被预约信息
	public ArrayList QueryDoc_appoint(String docname)throws Exception{
		
		ArrayList Doc_appoint=new ArrayList();
		
		String sql="SELECT * FROM H_AppointResult WHERE AR_docname=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,docname);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Appoint_Result_bean AR_doc=new Appoint_Result_bean();
			AR_doc.setAr_num(rs.getInt("AR_num"));
			AR_doc.setAr_name(rs.getString("AR_name"));
			AR_doc.setAr_idcard(rs.getString("AR_idcard"));
			AR_doc.setAr_idnum(rs.getInt("AR_idnum"));
			AR_doc.setAr_sex(rs.getString("AR_sex"));
			AR_doc.setAr_time(rs.getString("AR_time"));
			AR_doc.setAr_departname(rs.getString("AR_departname"));
			AR_doc.setAr_docname(rs.getString("AR_docname"));
			AR_doc.setAr_describe(rs.getString("AR_describe"));
			
			Doc_appoint.add(AR_doc);
		}
	  
	    return Doc_appoint;
		
	   }
	

	//在数据库中查询用户的（历史）预约信息（管理员：直接查询）
	public ArrayList QueryAll_appoint()throws Exception{
		
		ArrayList Allappoint=new ArrayList();
		
		String sql="SELECT * FROM H_AppointResult";
		
		PreparedStatement ps=con.prepareStatement(sql);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Appoint_Result_bean AR_all=new Appoint_Result_bean();
			AR_all.setAr_num(rs.getInt("AR_num"));
			AR_all.setAr_name(rs.getString("AR_name"));
			AR_all.setAr_idcard(rs.getString("AR_idcard"));
			AR_all.setAr_idnum(rs.getInt("AR_idnum"));
			AR_all.setAr_sex(rs.getString("AR_sex"));
			AR_all.setAr_time(rs.getString("AR_time"));
			AR_all.setAr_departname(rs.getString("AR_departname"));
			AR_all.setAr_docname(rs.getString("AR_docname"));
			AR_all.setAr_describe(rs.getString("AR_describe"));
			
			Allappoint.add(AR_all);
		}
	  
	    return Allappoint;
		
	   }
	
	
	//在数据库中根据删除预约信息（根据用户唯一编号和日期）
	public void Delete_appoint(int idnum,String time)throws Exception{
		
		ArrayList deappoint=new ArrayList();
		
		String sql="DELETE FROM H_AppointResult WHERE AR_idnum=? and AR_time=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,idnum);
		ps.setString(2,time);
		//ps.setDate(2,new java.sql.Date(time.getTime()));
		
		ps.executeUpdate();
		
	   }
	
	//在数据库中根据删除某条预约信息（根据预约结果序号）
	public void Delete_appoint_arnum(int arnum)throws Exception{
		
		ArrayList deappoint=new ArrayList();
		
		String sql="DELETE FROM H_AppointResult WHERE AR_num=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setInt(1,arnum);
		
		ps.executeUpdate();
		
	   }

	//在数据库排班表中查询医生的值班信息（查询排班表）
	public ArrayList Query_Jobtime()throws Exception{
		
		ArrayList jobtime=new ArrayList();
		
		String sql="SELECT * FROM H_JobTime";
		
		PreparedStatement ps=con.prepareStatement(sql);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next()){
			Doctor_Jobtime_bean doctime=new Doctor_Jobtime_bean();
			doctime.setJobn(rs.getInt("Job_n"));
			doctime.setJobdepartid(rs.getString("Job_Departid"));
			doctime.setJobdocid(rs.getString("Job_Docid"));
			doctime.setJobday(rs.getString("Job_day"));
			doctime.setJobnumber(rs.getInt("Job_number"));
			
			jobtime.add(doctime);
		}
		
		return jobtime;
	   }
	
	//在数据库中查询医生值班信息（直接查询）
	public ArrayList Query_jobtime_info()throws Exception{
		
		ArrayList jobtime_info=new ArrayList();
		
	    //Statement st=con.createStatement();
	    
	    String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_id,D_name,H_JobTime.Job_n,Job_day,Job_number FROM H_Department,H_Doctor,H_JobTime WHERE H_Department.D_departid=H_Doctor.D_departid and H_Department.D_departid=H_JobTime.Job_Departid and H_Doctor.D_id=H_JobTime.Job_Docid";
	    
	    PreparedStatement ps=con.prepareStatement(sql);

	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Appoint_bean jobtimeinfo=new Appoint_bean(); 
	    	jobtimeinfo.setJobn(rs.getInt("Job_n"));
	    	jobtimeinfo.setDepartid(rs.getString("D_departid"));
	    	jobtimeinfo.setDepartname(rs.getString("D_departname"));
	    	jobtimeinfo.setDocid(rs.getString("D_id"));
	    	jobtimeinfo.setDocname(rs.getString("D_name"));
	    	jobtimeinfo.setJobday(rs.getString("Job_day"));
	    	jobtimeinfo.setJobnumber(rs.getInt("Job_number"));
	    	
	    	jobtime_info.add(jobtimeinfo);
	   
	    }
	    return jobtime_info;
	   }
	

	//在数据库中查询值班信息（根据排班表序号、科室编号、医生工号、科室名称、医生姓名查询）
	public ArrayList Query_Doc_jobtime(String other)throws Exception{
		
		ArrayList time=new ArrayList();
		
	    //Statement st=con.createStatement();
	    
	   // String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_id,D_name,H_JobTime.Job_n,Job_day,Job_number FROM H_JobTime inner join H_Doctor on H_Doctor.D_id=H_JobTime.Job_Docid inner join H_Department on H_Department.D_departid=H_JobTime.Job_Departid and H_Department.D_departid=H_Doctor.D_departid WHERE H_Department.D_departname like '%"+other+"%' or H_Department.D_departid like '%"+other+"%' or Job_n like '%"+other+"%' or Job_Docid like '%"+other+"%' or  D_name like '%"+other+"%'";

	   // Statement ps=con.createStatement();
		String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_id,D_name,H_JobTime.Job_n,Job_day,Job_number FROM H_JobTime inner join H_Doctor on H_Doctor.D_id=H_JobTime.Job_Docid inner join H_Department on H_Department.D_departid=H_JobTime.Job_Departid and H_Department.D_departid=H_Doctor.D_departid WHERE H_Department.D_departname like ? or H_Department.D_departid like ? or Job_n like ? or Job_Docid like ? or  D_name like ?";

	    PreparedStatement ps=con.prepareStatement(sql);

	    ps.setString(1,"%"+other+"%");
	    ps.setString(2,"%"+other+"%");
	    ps.setString(3,"%"+other+"%");
	    ps.setString(4,"%"+other+"%");
	    ps.setString(5,"%"+other+"%");
	    
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Appoint_bean jobtime=new Appoint_bean();
	    	jobtime.setJobn(rs.getInt("Job_n"));
	    	jobtime.setDepartid(rs.getString("D_departid"));
	    	jobtime.setDepartname(rs.getString("D_departname"));
	    	jobtime.setDocid(rs.getString("D_id"));
	    	jobtime.setDocname(rs.getString("D_name"));
	    	jobtime.setJobday(rs.getString("Job_day"));
	    	jobtime.setJobnumber(rs.getInt("Job_number"));
	    	
	    	time.add(jobtime);
	   
	    }
	    return time;
	   }
	
	//根据排班表序号查询医生的值班信息（先查询，获取信息）
	public ArrayList Up_Doc_jobtime(int jobn)throws Exception{
		
		ArrayList Up_Doc_jobtime=new ArrayList();
		
		String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_id,D_name,H_JobTime.Job_n,Job_day,Job_number FROM H_Department,H_Doctor,H_JobTime WHERE H_Department.D_departid=H_Doctor.D_departid and H_Department.D_departid=H_JobTime.Job_Departid and H_Doctor.D_id=H_JobTime.Job_Docid and Job_n=?";
	    
		PreparedStatement ps=con.prepareStatement(sql);
	    ps.setInt(1,jobn);
	    
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Appoint_bean jobtime=new Appoint_bean();
	    	jobtime.setJobn(rs.getInt("Job_n"));
	    	jobtime.setDepartid(rs.getString("D_departid"));
	    	jobtime.setDepartname(rs.getString("D_departname"));
	    	jobtime.setDocid(rs.getString("D_id"));
	    	jobtime.setDocname(rs.getString("D_name"));
	    	jobtime.setJobday(rs.getString("Job_day"));
	    	jobtime.setJobnumber(rs.getInt("Job_number"));
	    	
	    	Up_Doc_jobtime.add(jobtime);
	   
	    }
	    return Up_Doc_jobtime;
	   }
	
	
	//在数据库中删除某条值班信息
	public void delete_Jobtime(int jobn)throws Exception{
	
		String sql="DELETE FROM H_JobTime WHERE Job_n=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
	    ps.setInt(1,jobn);
	   
	    ps.executeUpdate();

	   }
	

	//管理员在数据库中更新某条值班信息（只能更新值班时间、挂号量）对排班表进行操作。
	public void Update_Jobtime(int jobn,String jobday,int jobnumber)throws Exception{
	
		String sql="UPDATE H_JobTime SET Job_day=?,Job_number=? WHERE Job_n=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,jobday);
		//ps.setDate(1,new java.sql.Date(jobday.getTime()));
		ps.setInt(2,jobnumber);  
	    ps.setInt(3,jobn);
	    
	    ps.executeUpdate();

	   }
	
	//对医生进行排班操作 （对排班表进行操作。增添值班信息）
	public void Add_Jobtime(Doctor_Jobtime_bean jobtime)throws Exception{
		
	   String sql="insert into H_JobTime(Job_Departid,Job_Docid,Job_day,Job_number) values(?,?,?,?)";
	   PreparedStatement ps=con.prepareStatement(sql);
	   
		ps.setString(1, jobtime.getJobdepartid());
		ps.setString(2, jobtime.getJobdocid());
		ps.setString(3, jobtime.getJobday());
		//ps.setDate(3, new java.sql.Date(jobtime.getJobday().getTime()));
		ps.setInt(4, jobtime.getJobnumber());
		
		ps.executeUpdate();
			   
	  }
}
