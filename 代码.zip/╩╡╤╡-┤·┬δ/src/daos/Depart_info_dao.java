package daos;

import java.sql.*;
import java.util.ArrayList;

import beans.Depart_Doc_info_bean;
import beans.Depart_info_bean;


public class Depart_info_dao {
		Connection con=Connect_dao.connect();
	
	//在数据库中查询科室信息（按科室编号）
	public ArrayList query_department(String D_departid)throws Exception{
		
		ArrayList depart=new ArrayList();
 
	    String sql="select * from H_Department where D_departid=?";
	    PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1, D_departid);
	    
	    //ResultSet rs=st.executeQuery(sql);
	    
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Depart_info_bean Depart=new Depart_info_bean();
	    	
	    	Depart.setDepartname(rs.getString("D_departname"));
	    	Depart.setDepartintro(rs.getString("D_departintro"));
	    	depart.add(Depart);   	
	    }
	    return depart;
	}
	
	//在数据库中查询科室中任职医生的信息
	public ArrayList query_departDoc(String docdepart)throws Exception{
		
		ArrayList dedoc=new ArrayList();
 
	    String sql="SELECT H_Department.D_departid,D_departname,H_Doctor.D_name,D_intro FROM H_Department inner join H_Doctor on H_Department.D_departid=H_Doctor.D_departid  WHERE H_Department.D_departid=H_Doctor.D_departid and H_Department.D_departid like '%"+docdepart+"%' or D_departname like '%"+docdepart+"%'";
	   
	    //PreparedStatement ps=con.prepareStatement(sql);
	    //ps.setString(1,D_departid);
	    
	    Statement st=con.createStatement();
	    ResultSet rs=st.executeQuery(sql);
	    
	   // ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Depart_Doc_info_bean departdoc=new Depart_Doc_info_bean();
	    	departdoc.setDepartid(rs.getString("D_departid"));
	    	departdoc.setDepartname(rs.getString("D_departname"));
	    	departdoc.setDocname(rs.getString("D_name"));
	    	departdoc.setDocintro(rs.getString("D_intro"));
	    	
	    	dedoc.add(departdoc);   	
	    }
	    return dedoc;
	}
	
}
