package daos;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import beans.Admin_Allinfo_search_bean;
import beans.P_check_bean;



public class Functionss_dao {
	
	Connection con=Connect_dao.connect();
	
	
	//直接查询管理员的个人信息
	public ArrayList queryAdmin()throws Exception{
		
		ArrayList query=new ArrayList();
	    
	    String sql="select * from H_Admin";
	    //PreparedStatement ps=con.prepareStatement(sql);
	    //ps.setString(1,num);
	    Statement ps=con.createStatement();
	    
	    ResultSet rs=ps.executeQuery(sql);
	    while(rs.next()){
	    	Admin_Allinfo_search_bean Admin=new Admin_Allinfo_search_bean();
	    	Admin.setAdnum(rs.getString("Admin_num"));
	    	Admin.setAdidcard(rs.getString("Admin_idcard"));
	    	Admin.setAdname(rs.getString("Admin_name"));
	    	Admin.setAdsex(rs.getString("Admin_sex"));
	    	Admin.setAdage(rs.getString("Admin_age"));
	    	Admin.setAdphone(rs.getString("Admin_phone"));
	    	Admin.setAdpwd(rs.getString("Admin_pwd"));
	    	query.add(Admin);
	    }
	    
	    return query;
	   }
	

	//查询系统管理员的信息（按工号和姓名）
	public ArrayList query_Admin(String admin1)throws Exception{
		
		ArrayList admin=new ArrayList();
	    
	    String sql="select * from H_Admin where Admin_num like '%"+admin1+"%' or Admin_name like '%"+admin1+"%'";

	    Statement ps=con.createStatement();
	    
	    ResultSet rs=ps.executeQuery(sql);
	    while(rs.next()){
	    	Admin_Allinfo_search_bean admin_bean=new Admin_Allinfo_search_bean();
	    	admin_bean.setAdnum(rs.getString("Admin_num"));
	    	admin_bean.setAdidcard(rs.getString("Admin_idcard"));
	    	admin_bean.setAdname(rs.getString("Admin_name"));
	    	admin_bean.setAdsex(rs.getString("Admin_sex"));
	    	admin_bean.setAdage(rs.getString("Admin_age"));
	    	admin_bean.setAdphone(rs.getString("Admin_phone"));
	    	admin_bean.setAdpwd(rs.getString("Admin_pwd"));
	    	
	    	admin.add(admin_bean);
	    }
	    
	    return admin;
	   }
	
	//在数据库中删除管理员的信息
	public void deleteAdmin(String adid)throws Exception{
	
		String sql="DELETE FROM H_Admin where Admin_num=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1,adid);
	   
	    ps.executeUpdate();

	   }
	

	//在数据库中更新管理员的信息
	public void UpdateAdmin(String adid,String adname,String adage,String adphone,String adpwd)throws Exception{
	
		String sql="UPDATE H_Admin SET Admin_name=?,Admin_age=?,Admin_phone=?,Admin_pwd=? WHERE Admin_num=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,adname);
		ps.setString(2,adage);
	    ps.setString(3,adphone);
	    ps.setString(4,adpwd);
	    ps.setString(5,adid);

	    ps.executeUpdate();

	   }

	//在数据库中添加管理员
	public void addAdmin(Admin_Allinfo_search_bean addad)throws Exception{
	
		String sql="INSERT INTO H_Admin(Admin_num,Admin_idcard,Admin_name,Admin_sex,Admin_age,Admin_phone,Admin_pwd) VALUES(?,?,?,?,?,?,?)";
		
		PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1,addad.getAdnum());
	    ps.setString(2,addad.getAdidcard());
	    ps.setString(3,addad.getAdname());
	    ps.setString(4,addad.getAdsex());
	    ps.setString(5,addad.getAdage());
	    ps.setString(6,addad.getAdphone());
	    ps.setString(7,addad.getAdpwd());
	    ps.executeUpdate();
		
	   }
	
	
	//管理员在数据库中直接查询用户信息
	public ArrayList Query_Patient()throws Exception{
		
		ArrayList patient=new ArrayList();
		
	   String sql="select * from H_Patient";
	   PreparedStatement ps=con.prepareStatement(sql);
	   //ps.setInt(1,idnum);
	   
	   ResultSet rs=ps.executeQuery();
	   while(rs.next()){
	   	P_check_bean pbean2=new P_check_bean();
	    pbean2.setName(rs.getString("P_name"));
	    pbean2.setIdnum(rs.getInt("P_idnum"));
	    pbean2.setSex(rs.getString("P_sex"));
	    pbean2.setAge(rs.getString("P_age"));
	    pbean2.setIdcard(rs.getString("P_idcard"));
	    pbean2.setTel(rs.getString("P_phone"));
	    pbean2.setPwd(rs.getString("P_pwd"));
	    pbean2.setMedintro(rs.getString("P_medintro"));
	    
	    patient.add(pbean2);
	   }
	     
	   return patient;
	  }
	
	//管理员根据用户编号、用户姓名查询用户（任意词的查找）
	public ArrayList Query_Patients(String patient)throws Exception{
		
		ArrayList patients=new ArrayList();
		
	   String sql="select * from H_Patient where P_idnum like ? or P_name like ?";
	   PreparedStatement ps=con.prepareStatement(sql);
	   ps.setString(1, "%"+patient+"%");
	   ps.setString(2,"%"+patient+"%");
	   
	   ResultSet rs=ps.executeQuery();
	   while(rs.next()){
	   	P_check_bean pabean=new P_check_bean();
	   	pabean.setName(rs.getString("P_name"));
	   	pabean.setIdnum(rs.getInt("P_idnum"));
	   	pabean.setSex(rs.getString("P_sex"));
	   	pabean.setAge(rs.getString("P_age"));
	   	pabean.setIdcard(rs.getString("P_idcard"));
	   	pabean.setTel(rs.getString("P_phone"));
	   	pabean.setPwd(rs.getString("P_pwd"));
	   	pabean.setMedintro(rs.getString("P_medintro"));
	    
	    patients.add(pabean);
	   }
	     
	   return patients;
	  }
}
