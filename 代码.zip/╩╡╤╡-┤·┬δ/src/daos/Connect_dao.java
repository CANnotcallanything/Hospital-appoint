package daos;

import java.sql.*;

public class Connect_dao {
	
	public static Connection connect(){
	Connection con=null;
	 try {
		Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
		 String url="jdbc:sqlserver://localhost:1433;DatabaseName=Hospital";       
	     try {
			con=DriverManager.getConnection(url,"sa","080420");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	} catch (ClassNotFoundException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} 
     return con;
	}
}
