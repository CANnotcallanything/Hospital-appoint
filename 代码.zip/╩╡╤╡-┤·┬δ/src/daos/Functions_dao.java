package daos;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

import beans.Admin_Allinfo_search_bean;
import beans.Admin_bean;
import beans.Admin_searchDepart_bean;
import beans.Comment_bean;
import beans.Doctor_Allinfo_bean;
import beans.P_check_bean;
import beans.P_getinfo_bean;

public class Functions_dao {
	
	Connection con=Connect_dao.connect();

	//登录时在数据库中查询系统管理员的身份信息
	public ArrayList queryAdmin(String num,String id)throws Exception{
				
		ArrayList admin=new ArrayList();
	    
	    String sql="select * from H_Admin where Admin_num=? and Admin_pwd=?";
	    PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1, num);
	    ps.setString(2, id);
	    
	    ResultSet rs=ps.executeQuery();
	    while(rs.next()){
	    	Admin_bean adminbean=new Admin_bean();
	    	adminbean.setAdmin_id(rs.getString("Admin_num"));
	    	adminbean.setAdmin_name(rs.getString("Admin_name"));
	    	admin.add(adminbean);
	    }
	  
	    return admin;
	   }

	//登录时在数据库中查询核对医生的身份信息
	public ArrayList checkdoctor(String name,String pwd)throws Exception{
		
		ArrayList doctor=new ArrayList();
		
	   String sql="select * from H_Doctor where D_name=? and D_pwd=?";
	   PreparedStatement ps=con.prepareStatement(sql);
	   ps.setString(1, name);
	   ps.setString(2, pwd);
	
	   
	   ResultSet rs=ps.executeQuery();
	   while(rs.next()){
		Doctor_Allinfo_bean docbean=new Doctor_Allinfo_bean();
		  docbean.setDocid(rs.getString("D_id"));
		  docbean.setDocname(rs.getString("D_name"));
		  docbean.setDocsex(rs.getString("D_sex"));
		  docbean.setDocage(rs.getString("D_age"));
		  docbean.setDocidcard(rs.getString("D_idcard"));
		  docbean.setDocdepartid(rs.getString("D_departid"));
		  docbean.setDocphone(rs.getString("D_phone"));
		  docbean.setDocemail(rs.getString("D_email"));
		  docbean.setDocintro(rs.getString("D_intro"));
		  docbean.setDocpwd(rs.getString("D_pwd"));
	   	
	   	doctor.add(docbean);
	   }
	   return doctor;
	}
	   
	   //在数据库中直接查询医生信息
	   public ArrayList querydoctor()throws Exception{
			
		ArrayList doctors=new ArrayList();
			
		   String sql="select * from H_Doctor";
		
		   Statement ps=con.createStatement();
		    
		    ResultSet rs=ps.executeQuery(sql);
		   while(rs.next()){
			  Doctor_Allinfo_bean dbean=new Doctor_Allinfo_bean();
			  dbean.setDocid(rs.getString("D_id"));
			  dbean.setDocname(rs.getString("D_name"));
			  dbean.setDocsex(rs.getString("D_sex"));
			  dbean.setDocage(rs.getString("D_age"));
			  dbean.setDocidcard(rs.getString("D_idcard"));
			  dbean.setDocdepartid(rs.getString("D_departid"));
			  dbean.setDocphone(rs.getString("D_phone"));
			  dbean.setDocemail(rs.getString("D_email"));
			  dbean.setDocintro(rs.getString("D_intro"));
		   
		   	doctors.add(dbean);
		   }

		   return doctors;
	  }
	   
	   //在数据库中根据关键字查询医生信息
	   public ArrayList queryDoctors(String doctor)throws Exception{
			
		ArrayList doc=new ArrayList();
			
		   String sql="select * from H_Doctor where D_id like '%"+doctor+"%' or D_name like '%"+doctor+"%'";
		
		   Statement ps=con.createStatement();
		    
		    ResultSet rs=ps.executeQuery(sql);
		   while(rs.next()){
			  Doctor_Allinfo_bean docbean=new Doctor_Allinfo_bean();
			  docbean.setDocid(rs.getString("D_id"));
			  docbean.setDocname(rs.getString("D_name"));
			  docbean.setDocsex(rs.getString("D_sex"));
			  docbean.setDocage(rs.getString("D_age"));
			  docbean.setDocidcard(rs.getString("D_idcard"));
			  docbean.setDocdepartid(rs.getString("D_departid"));
			  docbean.setDocphone(rs.getString("D_phone"));
			  docbean.setDocemail(rs.getString("D_email"));
			  docbean.setDocintro(rs.getString("D_intro"));
			  docbean.setDocpwd(rs.getString("D_pwd"));
		   
		   	doc.add(docbean);
		   }

		   return doc;
	  }
	   
		//在数据库中删除医生信息
		public void deleteAdmin_Doc(String docid)throws Exception{
		
			String sql="DELETE FROM H_Doctor WHERE D_id=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
		    ps.setString(1,docid);
		   
		    ps.executeUpdate();

		   }
		
	   
	 //在数据库中更新医生的信息（医生自己修改）
		public void UpdateDoctor(String docid,String docname,String docage,String docphone,String docemail,String docintro,String docpwd)throws Exception{
		
			String sql="UPDATE H_Doctor SET D_name=?,D_age=?,D_phone=?,D_email=?,D_intro=?,D_pwd=? WHERE D_id=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,docname);
			ps.setString(2,docage);
		    ps.setString(3,docphone);
		    ps.setString(4,docemail);
		    ps.setString(5,docintro);
		    ps.setString(6,docpwd);
		    ps.setString(7,docid);

		    ps.executeUpdate();

		   }
	   

		//在数据库中更新医生的信息（管理员修改：可修改所属科室编号）
		public void Admin_UpdateDoctor(String docid,String docname,String docage,String docdepartid,String docphone,String docemail,String docintro,String docpwd)throws Exception{
		
			String sql="UPDATE H_Doctor SET D_name=?,D_age=?,D_departid=?,D_phone=?,D_email=?,D_intro=?,D_pwd=? WHERE D_id=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,docname);
			ps.setString(2,docage);
			ps.setString(3,docdepartid);
		    ps.setString(4,docphone);
		    ps.setString(5,docemail);
		    ps.setString(6,docintro);
		    ps.setString(7,docpwd);
		    ps.setString(8,docid);

		    ps.executeUpdate();

		   }
		

		//在数据库中添加新入职的医生信息
		public void addDoctor(Doctor_Allinfo_bean adddoc)throws Exception{
		
			String sql="INSERT INTO H_Doctor VALUES(?,?,?,?,?,?,?,?,?,?)";
			
			PreparedStatement ps=con.prepareStatement(sql);
		    ps.setString(1,adddoc.getDocid());
		    ps.setString(2,adddoc.getDocname());
		    ps.setString(3,adddoc.getDocsex());
		    ps.setString(4,adddoc.getDocage());
		    ps.setString(5,adddoc.getDocidcard());
		    ps.setString(6,adddoc.getDocdepartid());
		    ps.setString(7,adddoc.getDocphone());		    
		    ps.setString(8,adddoc.getDocemail());
		    ps.setString(9,adddoc.getDocintro());
		    ps.setString(10,adddoc.getDocpwd());
		    
		    ps.executeUpdate();
			
		   }
		
	 //把医生的评价信息写进数据库
		public void SaveComment(String docid,String datetime,String comment)throws Exception{
		
			String sql="INSERT INTO H_Comment(Com_docid,Comment,Com_time) VALUES(?,?,?)";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,docid);
			ps.setString(2,comment);
			ps.setString(3, datetime);
			//ps.setDate(3, new java.sql.Date(datetime.getTime()));
			//ps.setTimestamp(3,new java.sql.Timestamp(datetime.getTime()));
		    ps.executeUpdate();

		   }
		
		//医生查看自己的评价信息
		public ArrayList SearchDoc_Comment(String docid)throws Exception{
		
			ArrayList mycom=new ArrayList();
			
			String sql="SELECT Comment,Com_time FROM H_Comment WHERE Com_docid=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setString(1,docid);
			
		    ResultSet rs=ps.executeQuery();
		    while(rs.next()){
		    	Comment_bean doccom=new Comment_bean();
		    	doccom.setComment(rs.getString("Comment"));
		    	doccom.setComtime(rs.getString("Com_time"));
		    	
		    	mycom.add(doccom);
		    }

		    return mycom;
		   }
		
		
		//管理员查看系统的评价反馈信息
		public ArrayList Admin_Query_Comment()throws Exception{
			
			ArrayList comment=new ArrayList();
			
			String sql="SELECT * FROM H_Comment";
			
			PreparedStatement ps=con.prepareStatement(sql);
			
		    ResultSet rs=ps.executeQuery();
		    while(rs.next()){
		    	Comment_bean com=new Comment_bean();
		    	com.setComid(rs.getInt("Com_id"));
		    	com.setCompidnum(rs.getInt("Com_pidnum"));
		    	com.setComdocid(rs.getString("Com_docid"));
		    	com.setComment(rs.getString("Comment"));
		    	com.setComtime(rs.getString("Com_time"));
		    	
		    	comment.add(com);
		    }

		    return comment;
		   }
		
		
		//管理员删除系统的评价反馈信息
		public void Admin_Delete_Comment(int comid)throws Exception{
			
			ArrayList comment=new ArrayList();
			
			String sql="DELETE FROM H_Comment WHERE Com_id=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1, comid);
		    
		    ps.executeUpdate();
		   }
		
		
		//把普通用户的评价信息写进数据库
		public void SaveP_Comment(int idnum,String comment,String datetime)throws Exception{
		
			String sql="INSERT INTO H_Comment(Com_pidnum,Comment,Com_time) VALUES(?,?,?)";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,idnum);
			ps.setString(2,comment);
			ps.setString(3, datetime);
			//ps.setDate(3, new java.sql.Date(datetime.getTime()));
			//ps.setTimestamp(3,new java.sql.Timestamp(datetime.getTime()));
		    ps.executeUpdate();

		   }
		
		//用户查看自己的评价信息
		public ArrayList SearchP_Comment(int idnum)throws Exception{
		
			ArrayList mycomment=new ArrayList();
			
			String sql="SELECT Comment,Com_time FROM H_Comment WHERE Com_pidnum=?";
			
			PreparedStatement ps=con.prepareStatement(sql);
			ps.setInt(1,idnum);
			
		    ResultSet rs=ps.executeQuery();
		    while(rs.next()){
		    	Comment_bean pcom=new Comment_bean();
		    	pcom.setComtime(rs.getString("Com_time"));
		    	pcom.setComment(rs.getString("Comment"));
		    	mycomment.add(pcom);
		    }

		    return mycomment;
		   }
		
	//登录时在数据库中查询并确认病人的身份信息
	public ArrayList checkPatient(String name,String pwd)throws Exception{
		
		ArrayList parray=new ArrayList();
		
	   String sql="select * from H_Patient where P_name=? and P_pwd=?";
	   PreparedStatement ps=con.prepareStatement(sql);
	   ps.setString(1,name);
	   ps.setString(2,pwd);
	   
	   //ResultSet rs=st.executeQuery(sql);
	   
	   ResultSet rs=ps.executeQuery();
	   while(rs.next()){
	   	P_check_bean pbean=new P_check_bean();
	    pbean.setName(rs.getString("P_name"));
	    pbean.setIdnum(rs.getInt("P_idnum"));
	    pbean.setSex(rs.getString("P_sex"));
	    pbean.setAge(rs.getString("P_age"));
	    pbean.setIdcard(rs.getString("P_idcard"));
	    pbean.setTel(rs.getString("P_phone"));
	    pbean.setPwd(rs.getString("P_pwd"));
	    pbean.setMedintro(rs.getString("P_medintro"));
	    parray.add(pbean);
	   }
	   
	  
	   return parray;
	  }
	
	//注册时将用户的登录信息存储到数据库中
	public void get_patientinfo(P_getinfo_bean infobean)throws Exception{
		
	   String sql="insert into H_Patient(P_idcard,P_name,P_sex,P_age,P_pwd,P_phone,P_medintro) values(?,?,?,?,?,?,?)";
	   PreparedStatement ps=con.prepareStatement(sql);
	   
			ps.setString(1, infobean.getIdcard());
			ps.setString(2, infobean.getUsername());
			ps.setString(3, infobean.getSex());
			ps.setString(4, infobean.getAge());
			ps.setString(5, infobean.getPwd());
			ps.setString(6, infobean.getTel());
			ps.setString(7, infobean.getMedintro());	  
			
			ps.executeUpdate();
			   
	  }
	
	//用户修改自己的个人信息
	public void UpdatePatient_info(int idnum,String pname,String pphone,String pmedintro,String ppwd)throws Exception{
	
		String sql="UPDATE H_Patient SET P_name=?,P_pwd=?,P_phone=?,P_medintro=? WHERE P_idnum=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,pname);
		ps.setString(2,ppwd);  
	    ps.setString(3,pphone);
	    ps.setString(4,pmedintro);
	    ps.setInt(5,idnum);

	    ps.executeUpdate();

	   }
	
	//在数据库中根据关键字查询科室信息
	public ArrayList queryDepartment(String department)throws Exception{
		
		ArrayList depart=new ArrayList();
	    
	    String sql="select * from H_Department where D_departid like '%"+department+"%' or D_departname like '%"+department+"%'";

	    Statement ps=con.createStatement();
	    
	    ResultSet rs=ps.executeQuery(sql);
	    while(rs.next()){
	    	Admin_searchDepart_bean departments=new Admin_searchDepart_bean();
	    	departments.setDepartid(rs.getString("D_departid"));
	    	departments.setDepartname(rs.getString("D_departname"));
	    	departments.setDepartintro(rs.getString("D_departintro"));
	    	depart.add(departments);
	    }
	   
	    
	    return depart;
	   }
	
	//在数据库中查询科室信息
	public ArrayList queryAdmin_depart()throws Exception{
		
		ArrayList querydepart=new ArrayList();
	    
	    String sql="select * from H_Department";
	    //PreparedStatement ps=con.prepareStatement(sql);
	   // ps.setString(1,name);
	    Statement ps=con.createStatement();
	    
	    ResultSet rs=ps.executeQuery(sql);
	    while(rs.next()){
	    	Admin_searchDepart_bean Admin_depart=new Admin_searchDepart_bean();
	    	Admin_depart.setDepartid(rs.getString("D_departid"));
	    	Admin_depart.setDepartname(rs.getString("D_departname"));
	    	Admin_depart.setDepartintro(rs.getString("D_departintro"));
	    	querydepart.add(Admin_depart);
	    }
	    
	    return querydepart;
	   }

	
	//在数据库中添加科室信息
	public void addAdmin_depart(Admin_searchDepart_bean addde)throws Exception{
	
		String sql="INSERT INTO H_Department(D_departid,D_departname,D_departintro) VALUES(?,?,?)";
		
		PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1,addde.getDepartid());
	    ps.setString(2,addde.getDepartname());
	    ps.setString(3,addde.getDepartintro());
	   
	    ps.executeUpdate();
		
	   }
	
	//在数据库中删除科室信息
	public void deleteAdmin_depart(String deid)throws Exception{
	
		String sql="DELETE FROM H_Department WHERE D_departid=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
	    ps.setString(1,deid);
	   
	    ps.executeUpdate();

	   }
	

	//在数据库中更新科室信息
	public void UpdateAdmin_depart(String deid,String dename,String deintro)throws Exception{
	
		String sql="UPDATE H_Department SET D_departname=?,D_departintro=? WHERE D_departid=?";
		
		PreparedStatement ps=con.prepareStatement(sql);
		ps.setString(1,dename);
		ps.setString(2,deintro);  
	    ps.setString(3,deid);

	    ps.executeUpdate();

	   }
}
